"""Secretless verifier connection handoff and read-backed lifecycle."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Literal, TypedDict

from ._core.clients import _AsyncClient, _SyncClient
from .errors import NetworkError, ProblemError


class NoExpiration(TypedDict):
    kind: Literal["no_expiration"]


class PresetDays(TypedDict):
    kind: Literal["preset_days"]
    days: Literal[30, 90, 180, 365]


class CalendarDate(TypedDict):
    kind: Literal["calendar_date"]
    date: str
    time_zone: str


StopChoice = NoExpiration | PresetDays | CalendarDate


class ConnectionIntent(TypedDict):
    continue_url: str
    intake_origin: str
    intent_id: str
    origin: str
    expires_at: str


def _checked_stop_choice(choice: StopChoice) -> StopChoice:
    if not isinstance(choice, dict):
        raise TypeError("invalid verifier stop choice")
    kind = choice.get("kind")
    if kind == "no_expiration" and set(choice) == {"kind"}:
        return {"kind": kind}
    if kind == "preset_days" and set(choice) == {"kind", "days"} and type(choice["days"]) is int and choice["days"] in {30, 90, 180, 365}:
        return {"kind": kind, "days": choice["days"]}
    if kind == "calendar_date" and set(choice) == {"kind", "date", "time_zone"}:
        date, time_zone = choice["date"], choice["time_zone"]
        if isinstance(date, str) and len(date) == 10 and isinstance(time_zone, str) and time_zone:
            return {"kind": kind, "date": date, "time_zone": time_zone}
    raise ValueError("invalid verifier stop choice")


@dataclass(frozen=True)
class LifecycleOutcome:
    state: Literal["action_required", "pending", "unknown", "test_failed", "changed", "nothing_pending", "refused", "done"]
    next_action: Literal["enter_key", "resume", "start_again", "inspect"] | None
    connection: Mapping[str, Any] | None
    error: Mapping[str, Any] | None = None


def _refusal(error: Exception, connection: Mapping[str, Any] | None) -> LifecycleOutcome | None:
    if isinstance(error, ProblemError):
        if error.status in {401, 403}:
            raise error
        if error.status < 500 and error.status not in {408, 429}:
            return LifecycleOutcome("refused", "inspect", connection,
                                    {"status": error.status, "title": error.title})
        return None
    if isinstance(error, NetworkError):
        return None
    raise error


def _operation(view: Mapping[str, Any]) -> Mapping[str, Any]:
    value = view.get("last_operation")
    return value if isinstance(value, dict) and value.get("status") != "unknown" else {}


def _staged_handle(view: Mapping[str, Any]) -> str | None:
    operation = _operation(view)
    state = operation.get("resulting_state")
    handle = state.get("handle") if isinstance(state, dict) and operation.get("kind") == "stage" else None
    return handle if isinstance(handle, str) else None


def _promotion_result(view: Mapping[str, Any], handle: str) -> LifecycleOutcome:
    if view.get("status") == "active" and view.get("handle") == handle:
        return LifecycleOutcome("done", None, view)
    last_test = view.get("last_test")
    if isinstance(last_test, dict) and last_test.get("outcome") == "failed" and last_test.get("handle") == handle:
        return LifecycleOutcome("test_failed", "start_again", view)
    pending = view.get("pending_key")
    if isinstance(pending, dict) and pending.get("handle") == handle:
        return LifecycleOutcome("pending", "resume", view)
    return LifecycleOutcome("changed", "inspect", view)


def _disconnect_result(view: Mapping[str, Any] | None) -> LifecycleOutcome:
    if view is None:
        return LifecycleOutcome("unknown", "resume", None)
    operation = _operation(view)
    if view.get("status") == "revoked" or (operation.get("kind") == "revoke" and operation.get("phase") == "committed"):
        return LifecycleOutcome("done", None, view)
    return LifecycleOutcome("unknown", "resume", view)


def _require_mapping(value: Any) -> Mapping[str, Any]:
    if not isinstance(value, dict):
        raise TypeError("verifier connection response must be an object")
    return value


class VerifierConnection:
    """Synchronous protected lifecycle. The key is entered at continue_url, never here."""

    def __init__(self, client: _SyncClient) -> None:
        self._client = client

    def create_intent(self, verifier_id: str, stop_choice: StopChoice, *, idempotency_key: str) -> ConnectionIntent:
        return _require_mapping(self._client._verifier_connection("intent", verifier_id,
                                body={"stop_choice": _checked_stop_choice(stop_choice)}, idempotency_key=idempotency_key))  # type: ignore[return-value]

    def inspect(self, verifier_id: str, *, operation_key: str | None = None) -> Mapping[str, Any]:
        query = {"operation_key": operation_key} if operation_key else None
        return _require_mapping(self._client._verifier_connection("inspect", verifier_id, query=query))

    def test_and_promote(self, verifier_id: str, *, handle: str, captured_generation: int,
                         operation_key: str, idempotency_key: str) -> Mapping[str, Any]:
        return _require_mapping(self._client._verifier_connection("promote", verifier_id,
                                body={"handle": handle, "captured_generation": captured_generation,
                                      "operation_key": operation_key}, idempotency_key=idempotency_key))

    def revoke(self, verifier_id: str, *, operation_key: str, idempotency_key: str) -> Mapping[str, Any]:
        return _require_mapping(self._client._verifier_connection("revoke", verifier_id,
                                body={"operation_key": operation_key}, idempotency_key=idempotency_key))

    def _safe_inspect(self, verifier_id: str, operation_key: str) -> Mapping[str, Any] | LifecycleOutcome | None:
        try:
            return self.inspect(verifier_id, operation_key=operation_key)
        except (ProblemError, NetworkError) as error:
            return _refusal(error, None)

    def continue_connection(self, verifier_id: str, *, operation_key: str, idempotency_key: str) -> LifecycleOutcome:
        before = self._safe_inspect(verifier_id, operation_key)
        if isinstance(before, LifecycleOutcome):
            return before
        if before is None:
            return LifecycleOutcome("unknown", "resume", None)
        operation = _operation(before)
        if operation.get("kind") == "promote" and operation.get("phase") == "committed":
            return LifecycleOutcome("done", None, before)
        handle = _staged_handle(before)
        if handle is None:
            return LifecycleOutcome("action_required", "enter_key", before)
        pending = before.get("pending_key")
        if isinstance(pending, dict) and pending.get("handle") != handle:
            return LifecycleOutcome("changed", "inspect", before)
        if not isinstance(pending, dict):
            return _promotion_result(before, handle)
        write_refusal = None
        try:
            self.test_and_promote(verifier_id, handle=handle,
                                  captured_generation=pending["captured_generation"],
                                  operation_key=operation_key, idempotency_key=idempotency_key)
        except (ProblemError, NetworkError) as error:
            write_refusal = _refusal(error, before)
        after = self._safe_inspect(verifier_id, operation_key)
        if isinstance(after, LifecycleOutcome):
            return after
        if after is None:
            return write_refusal or LifecycleOutcome("unknown", "resume", None)
        result = _promotion_result(after, handle)
        if write_refusal and result.state not in {"test_failed", "done"}:
            return LifecycleOutcome("refused", "inspect", after, write_refusal.error)
        return result

    def disconnect(self, verifier_id: str, *, operation_key: str, idempotency_key: str,
                   confirmed: bool) -> LifecycleOutcome:
        if not confirmed:
            raise ValueError("verifier disconnect requires explicit confirmation")
        write_refusal = None
        try:
            self.revoke(verifier_id, operation_key=operation_key, idempotency_key=idempotency_key)
        except (ProblemError, NetworkError) as error:
            write_refusal = _refusal(error, None)
        after = self._safe_inspect(verifier_id, operation_key)
        if isinstance(after, LifecycleOutcome):
            return after
        if after is None and write_refusal:
            return write_refusal
        result = _disconnect_result(after)
        if write_refusal and result.state != "done":
            return LifecycleOutcome("refused", "inspect", after, write_refusal.error)
        return result


class AsyncVerifierConnection:
    """Async equivalent of the secretless protected lifecycle."""

    def __init__(self, client: _AsyncClient) -> None:
        self._client = client

    async def create_intent(self, verifier_id: str, stop_choice: StopChoice, *, idempotency_key: str) -> ConnectionIntent:
        return _require_mapping(await self._client._verifier_connection("intent", verifier_id,
                                body={"stop_choice": _checked_stop_choice(stop_choice)}, idempotency_key=idempotency_key))  # type: ignore[return-value]

    async def inspect(self, verifier_id: str, *, operation_key: str | None = None) -> Mapping[str, Any]:
        query = {"operation_key": operation_key} if operation_key else None
        return _require_mapping(await self._client._verifier_connection("inspect", verifier_id, query=query))

    async def test_and_promote(self, verifier_id: str, *, handle: str, captured_generation: int,
                               operation_key: str, idempotency_key: str) -> Mapping[str, Any]:
        return _require_mapping(await self._client._verifier_connection("promote", verifier_id,
                                body={"handle": handle, "captured_generation": captured_generation,
                                      "operation_key": operation_key}, idempotency_key=idempotency_key))

    async def revoke(self, verifier_id: str, *, operation_key: str, idempotency_key: str) -> Mapping[str, Any]:
        return _require_mapping(await self._client._verifier_connection("revoke", verifier_id,
                                body={"operation_key": operation_key}, idempotency_key=idempotency_key))

    async def _safe_inspect(self, verifier_id: str, operation_key: str) -> Mapping[str, Any] | LifecycleOutcome | None:
        try:
            return await self.inspect(verifier_id, operation_key=operation_key)
        except (ProblemError, NetworkError) as error:
            return _refusal(error, None)

    async def continue_connection(self, verifier_id: str, *, operation_key: str, idempotency_key: str) -> LifecycleOutcome:
        before = await self._safe_inspect(verifier_id, operation_key)
        if isinstance(before, LifecycleOutcome):
            return before
        if before is None:
            return LifecycleOutcome("unknown", "resume", None)
        operation = _operation(before)
        if operation.get("kind") == "promote" and operation.get("phase") == "committed":
            return LifecycleOutcome("done", None, before)
        handle = _staged_handle(before)
        if handle is None:
            return LifecycleOutcome("action_required", "enter_key", before)
        pending = before.get("pending_key")
        if isinstance(pending, dict) and pending.get("handle") != handle:
            return LifecycleOutcome("changed", "inspect", before)
        if not isinstance(pending, dict):
            return _promotion_result(before, handle)
        write_refusal = None
        try:
            await self.test_and_promote(verifier_id, handle=handle,
                                        captured_generation=pending["captured_generation"],
                                        operation_key=operation_key, idempotency_key=idempotency_key)
        except (ProblemError, NetworkError) as error:
            write_refusal = _refusal(error, before)
        after = await self._safe_inspect(verifier_id, operation_key)
        if isinstance(after, LifecycleOutcome):
            return after
        if after is None:
            return write_refusal or LifecycleOutcome("unknown", "resume", None)
        result = _promotion_result(after, handle)
        if write_refusal and result.state not in {"test_failed", "done"}:
            return LifecycleOutcome("refused", "inspect", after, write_refusal.error)
        return result

    async def disconnect(self, verifier_id: str, *, operation_key: str, idempotency_key: str,
                         confirmed: bool) -> LifecycleOutcome:
        if not confirmed:
            raise ValueError("verifier disconnect requires explicit confirmation")
        write_refusal = None
        try:
            await self.revoke(verifier_id, operation_key=operation_key, idempotency_key=idempotency_key)
        except (ProblemError, NetworkError) as error:
            write_refusal = _refusal(error, None)
        after = await self._safe_inspect(verifier_id, operation_key)
        if isinstance(after, LifecycleOutcome):
            return after
        if after is None and write_refusal:
            return write_refusal
        result = _disconnect_result(after)
        if write_refusal and result.state != "done":
            return LifecycleOutcome("refused", "inspect", after, write_refusal.error)
        return result
