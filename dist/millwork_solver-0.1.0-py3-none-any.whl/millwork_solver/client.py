"""Signed public names over the name-neutral PY2 core."""

from __future__ import annotations

import os
from collections.abc import AsyncIterator, Iterator, Mapping
from importlib.resources import as_file, files
from typing import Any
from urllib.parse import urlsplit, urlunsplit

import httpx

from ._core.boundary import _create_async_client, _create_sync_client
from ._core.clients import _AsyncClient, _SyncClient
from .types import Page


def _required_setting(explicit: str | None, environment_name: str) -> str:
    selected = explicit if explicit is not None else os.environ.get(environment_name)
    if selected is None or not selected.strip():
        raise ValueError(f"{environment_name} is required")
    return selected


def _transport_base_url(explicit: str | None) -> str:
    configured = _required_setting(explicit, "SOLVERAPI_BASE_URL").strip()
    parsed = urlsplit(configured)
    if (
        parsed.scheme not in {"http", "https"}
        or not parsed.netloc
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
        or parsed.path.rstrip("/") not in {"", "/v1"}
    ):
        raise ValueError(
            "SOLVERAPI_BASE_URL must be an http(s) origin with optional /v1 suffix"
        )
    # The generated wire paths already begin with /v1. HTTPX otherwise appends
    # them beneath a configured /v1 base and sends /v1/v1/... .
    return urlunsplit((parsed.scheme, parsed.netloc, "", "", ""))


def _non_negative_integer_setting(
    explicit: int | None,
    environment_name: str,
    default: int,
) -> int:
    if explicit is not None:
        selected: object = explicit
    else:
        raw = os.environ.get(environment_name)
        selected = default if raw is None else raw
    if isinstance(selected, bool):
        raise ValueError(f"{environment_name} must be a non-negative integer")
    try:
        parsed = int(selected)
    except (TypeError, ValueError) as error:
        raise ValueError(f"{environment_name} must be a non-negative integer") from error
    if parsed < 0 or str(parsed) != str(selected).strip():
        raise ValueError(f"{environment_name} must be a non-negative integer")
    return parsed


def _snapshot_resource():
    return files("millwork_solver").joinpath("_contract.json")


class Solver:
    """Synchronous client for the signed 54-operation Python boundary."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        *,
        timeout: float | httpx.Timeout = 10.0,
        max_retries: int | None = None,
        retry_backoff_ms: int | None = None,
        _transport: httpx.BaseTransport | None = None,
    ) -> None:
        selected_retries = _non_negative_integer_setting(
            max_retries, "SOLVERAPI_MAX_RETRIES", 2
        )
        selected_backoff = _non_negative_integer_setting(
            retry_backoff_ms, "SOLVERAPI_RETRY_BACKOFF_MS", 500
        )
        self._snapshot_context = as_file(_snapshot_resource())
        snapshot_path = self._snapshot_context.__enter__()
        try:
            self._client: _SyncClient = _create_sync_client(
                snapshot_path=snapshot_path,
                credential=_required_setting(api_key, "SOLVERAPI_API_KEY"),
                base_url=_transport_base_url(base_url),
                timeout=timeout,
                maximum_retries=selected_retries,
                backoff_seconds=selected_backoff / 1000,
                transport=_transport,
            )
        except BaseException:
            self._snapshot_context.__exit__(None, None, None)
            raise
        self._closed = False

    def request(
        self,
        operation_id: str,
        *,
        path_parameters: Mapping[str, object] | None = None,
        query: Mapping[str, object] | None = None,
        body: object | None = None,
        idempotency_key: str | None = None,
    ) -> Any:
        return self._client.request(
            operation_id,
            path_parameters=path_parameters,
            query=query,
            body=body,
            idempotency_key=idempotency_key,
        )

    def pages(
        self,
        operation_id: str,
        *,
        item_field: str,
        path_parameters: Mapping[str, object] | None = None,
        query: Mapping[str, object] | None = None,
    ) -> Iterator[Page]:
        return self._client.pages(
            operation_id,
            item_field=item_field,
            path_parameters=path_parameters,
            query=query,
        )

    def events(
        self,
        *,
        path_parameters: Mapping[str, object],
        poll_interval_seconds: float = 1.0,
    ) -> Iterator[Mapping[str, Any]]:
        return self._client.events(
            path_parameters=path_parameters,
            poll_interval_seconds=poll_interval_seconds,
        )

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self._client.close()
            self._snapshot_context.__exit__(None, None, None)

    def __enter__(self) -> "Solver":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


class AsyncSolver:
    """Asynchronous client with a distinct httpx.AsyncClient transport."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        *,
        timeout: float | httpx.Timeout = 10.0,
        max_retries: int | None = None,
        retry_backoff_ms: int | None = None,
        _transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        selected_retries = _non_negative_integer_setting(
            max_retries, "SOLVERAPI_MAX_RETRIES", 2
        )
        selected_backoff = _non_negative_integer_setting(
            retry_backoff_ms, "SOLVERAPI_RETRY_BACKOFF_MS", 500
        )
        self._snapshot_context = as_file(_snapshot_resource())
        snapshot_path = self._snapshot_context.__enter__()
        try:
            self._client: _AsyncClient = _create_async_client(
                snapshot_path=snapshot_path,
                credential=_required_setting(api_key, "SOLVERAPI_API_KEY"),
                base_url=_transport_base_url(base_url),
                timeout=timeout,
                maximum_retries=selected_retries,
                backoff_seconds=selected_backoff / 1000,
                transport=_transport,
            )
        except BaseException:
            self._snapshot_context.__exit__(None, None, None)
            raise
        self._closed = False

    async def request(
        self,
        operation_id: str,
        *,
        path_parameters: Mapping[str, object] | None = None,
        query: Mapping[str, object] | None = None,
        body: object | None = None,
        idempotency_key: str | None = None,
    ) -> Any:
        return await self._client.request(
            operation_id,
            path_parameters=path_parameters,
            query=query,
            body=body,
            idempotency_key=idempotency_key,
        )

    def pages(
        self,
        operation_id: str,
        *,
        item_field: str,
        path_parameters: Mapping[str, object] | None = None,
        query: Mapping[str, object] | None = None,
    ) -> AsyncIterator[Page]:
        return self._client.pages(
            operation_id,
            item_field=item_field,
            path_parameters=path_parameters,
            query=query,
        )

    def events(
        self,
        *,
        path_parameters: Mapping[str, object],
        poll_interval_seconds: float = 1.0,
    ) -> AsyncIterator[Mapping[str, Any]]:
        return self._client.events(
            path_parameters=path_parameters,
            poll_interval_seconds=poll_interval_seconds,
        )

    async def aclose(self) -> None:
        if not self._closed:
            self._closed = True
            await self._client.aclose()
            self._snapshot_context.__exit__(None, None, None)

    async def __aenter__(self) -> "AsyncSolver":
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.aclose()
