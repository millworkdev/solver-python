"""Stable public RFC-7807, transport, protocol, and lifecycle failures."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class FieldError:
    field: str
    message: str


class ProblemError(Exception):
    """A conforming RFC-7807 response returned by the server."""

    def __init__(self, problem: Mapping[str, Any]) -> None:
        title = problem["title"]
        super().__init__(title)
        self.problem = dict(problem)
        self.problem_type = problem["type"]
        self.title = title
        self.status = problem["status"]
        self.detail = problem.get("detail")
        self.instance = problem["instance"]
        self.field_errors = tuple(
            FieldError(field=item["field"], message=item["message"])
            for item in problem.get("errors", ())
        )
        self.retry_after_seconds = problem.get("retry_after_s")
        self.code = self.problem_type.rstrip("/").rsplit("/", 1)[-1]
        self.retryable = self.status >= 500


class NetworkError(Exception):
    """The request did not produce a conforming HTTP response."""

    def __init__(self, message: str, *, cause: BaseException | None = None) -> None:
        super().__init__(message)
        self.cause = cause


class ProtocolError(Exception):
    """The server response violated the retained JSON/Problem contract."""


class OperationBoundaryError(Exception):
    """An operation is outside the pointer-resolved F1 Python boundary."""


class ClientClosedError(Exception):
    """A request was attempted after deterministic client shutdown."""

__all__ = (
    "ClientClosedError",
    "FieldError",
    "NetworkError",
    "OperationBoundaryError",
    "ProblemError",
    "ProtocolError",
)
