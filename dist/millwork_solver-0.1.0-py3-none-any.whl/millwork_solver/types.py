"""Stable public value types returned by the client facade."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Page:
    items: tuple[Any, ...]
    next_cursor: str | None


__all__ = ("Page",)
