"""Repository-internal PY2 core. No public import surface is selected here."""

__all__: tuple[str, ...] = ()
