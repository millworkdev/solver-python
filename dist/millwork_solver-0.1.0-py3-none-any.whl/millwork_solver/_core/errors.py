"""Private compatibility names bound to the stable public error classes."""

from ..errors import (
    ClientClosedError as _ClientClosedError,
    NetworkError as _NetworkTransportError,
    OperationBoundaryError as _OperationBoundaryError,
    ProblemError as _ProblemResponseError,
    ProtocolError as _ProtocolResponseError,
)

__all__: tuple[str, ...] = ()
