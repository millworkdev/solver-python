"""Repository-internal sync and async clients over the shared wire policy."""

from __future__ import annotations

from collections.abc import AsyncIterator, Iterator, Mapping
from typing import Any, Awaitable, Callable

from ..types import Page
from .catalog import _OperationCatalog
from .errors import _ClientClosedError, _ProtocolResponseError
from .transport import _AsyncTransport, _SyncTransport, _TransportPolicy, _prepare_request


def _page_from_response(response: Any, item_field: str) -> Page:
    if not isinstance(response, dict):
        raise _ProtocolResponseError("paginated response must be an object")
    items = response.get(item_field)
    cursor = response.get("next_cursor")
    if not isinstance(items, list) or (cursor is not None and not isinstance(cursor, str)):
        raise _ProtocolResponseError("paginated response has the wrong shape")
    return Page(tuple(items), cursor)


def _events_from_response(response: Any) -> tuple[Mapping[str, Any], ...]:
    if not isinstance(response, dict) or not isinstance(response.get("events"), list):
        raise _ProtocolResponseError("events response has the wrong shape")
    events = response["events"]
    if any(not isinstance(event, dict) for event in events):
        raise _ProtocolResponseError("event entries must be objects")
    return tuple(events)


def _is_terminal_event(event: Mapping[str, Any]) -> bool:
    return (
        event.get("type") == "lifecycle"
        and event.get("slice_id") is None
        and event.get("state") in {"completed", "failed", "cancelled", "expired"}
    )


class _SyncClient:
    def __init__(
        self,
        catalog: _OperationCatalog,
        policy: _TransportPolicy,
        transport: _SyncTransport,
        *,
        close_transport: Callable[[], None],
        sleep: Callable[[float], None],
    ) -> None:
        self._catalog = catalog
        self._policy = policy
        self._transport = transport
        self._close_transport = close_transport
        self._sleep = sleep
        self._closed = False

    def _ensure_open(self) -> None:
        if self._closed:
            raise _ClientClosedError("client is closed")

    def _resolve_fixture_request(self, method: str, path: str) -> tuple[str, Mapping[str, str]]:
        return self._catalog.match_fixture_request(method, path)

    def request(
        self,
        operation_id: str,
        *,
        path_parameters: Mapping[str, object] | None = None,
        query: Mapping[str, object] | None = None,
        body: object | None = None,
        idempotency_key: str | None = None,
    ) -> Any:
        self._ensure_open()
        operation = self._catalog.operation(operation_id)
        prepared = _prepare_request(
            operation_id=operation.operation_id,
            method=operation.method,
            path=operation.bind_path(path_parameters),
            query=query,
            body=body,
            idempotency_key=idempotency_key,
            policy=self._policy,
        )
        return self._transport.execute(prepared)

    def pages(
        self,
        operation_id: str,
        *,
        item_field: str,
        path_parameters: Mapping[str, object] | None = None,
        query: Mapping[str, object] | None = None,
    ) -> Iterator[Page]:
        cursor: str | None = None
        while True:
            page_query = dict(query or {})
            if cursor is not None:
                page_query["cursor"] = cursor
            page = _page_from_response(
                self.request(
                    operation_id,
                    path_parameters=path_parameters,
                    query=page_query,
                ),
                item_field,
            )
            yield page
            if page.next_cursor is None:
                return
            cursor = page.next_cursor

    def events(
        self,
        *,
        path_parameters: Mapping[str, object],
        poll_interval_seconds: float = 1.0,
    ) -> Iterator[Mapping[str, Any]]:
        if poll_interval_seconds < 0:
            raise ValueError("poll_interval_seconds must not be negative")
        after: str | None = None
        while True:
            events = _events_from_response(
                self.request(
                    self._catalog.event_operation_id,
                    path_parameters=path_parameters,
                    query={"after": after},
                )
            )
            if not events:
                self._sleep(poll_interval_seconds)
            for event in events:
                yield event
                event_id = event.get("event_id")
                if not isinstance(event_id, str):
                    raise _ProtocolResponseError("event_id must be a string")
                after = event_id
                if _is_terminal_event(event):
                    return

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self._close_transport()

    def __enter__(self) -> "_SyncClient":
        self._ensure_open()
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


class _AsyncClient:
    def __init__(
        self,
        catalog: _OperationCatalog,
        policy: _TransportPolicy,
        transport: _AsyncTransport,
        *,
        close_transport: Callable[[], Awaitable[None]],
        sleep: Callable[[float], Awaitable[None]],
    ) -> None:
        self._catalog = catalog
        self._policy = policy
        self._transport = transport
        self._close_transport = close_transport
        self._sleep = sleep
        self._closed = False

    def _ensure_open(self) -> None:
        if self._closed:
            raise _ClientClosedError("client is closed")

    def _resolve_fixture_request(self, method: str, path: str) -> tuple[str, Mapping[str, str]]:
        return self._catalog.match_fixture_request(method, path)

    async def request(
        self,
        operation_id: str,
        *,
        path_parameters: Mapping[str, object] | None = None,
        query: Mapping[str, object] | None = None,
        body: object | None = None,
        idempotency_key: str | None = None,
    ) -> Any:
        self._ensure_open()
        operation = self._catalog.operation(operation_id)
        prepared = _prepare_request(
            operation_id=operation.operation_id,
            method=operation.method,
            path=operation.bind_path(path_parameters),
            query=query,
            body=body,
            idempotency_key=idempotency_key,
            policy=self._policy,
        )
        return await self._transport.execute(prepared)

    async def pages(
        self,
        operation_id: str,
        *,
        item_field: str,
        path_parameters: Mapping[str, object] | None = None,
        query: Mapping[str, object] | None = None,
    ) -> AsyncIterator[Page]:
        cursor: str | None = None
        while True:
            page_query = dict(query or {})
            if cursor is not None:
                page_query["cursor"] = cursor
            page = _page_from_response(
                await self.request(
                    operation_id,
                    path_parameters=path_parameters,
                    query=page_query,
                ),
                item_field,
            )
            yield page
            if page.next_cursor is None:
                return
            cursor = page.next_cursor

    async def events(
        self,
        *,
        path_parameters: Mapping[str, object],
        poll_interval_seconds: float = 1.0,
    ) -> AsyncIterator[Mapping[str, Any]]:
        if poll_interval_seconds < 0:
            raise ValueError("poll_interval_seconds must not be negative")
        after: str | None = None
        while True:
            events = _events_from_response(
                await self.request(
                    self._catalog.event_operation_id,
                    path_parameters=path_parameters,
                    query={"after": after},
                )
            )
            if not events:
                await self._sleep(poll_interval_seconds)
            for event in events:
                yield event
                event_id = event.get("event_id")
                if not isinstance(event_id, str):
                    raise _ProtocolResponseError("event_id must be a string")
                after = event_id
                if _is_terminal_event(event):
                    return

    async def aclose(self) -> None:
        if not self._closed:
            self._closed = True
            await self._close_transport()

    async def __aenter__(self) -> "_AsyncClient":
        self._ensure_open()
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.aclose()
