"""The sole name-neutral seam for a future PY0-selected public API.

This repository-internal module deliberately exposes no distribution, import,
public client-class, environment-variable, runtime-support, or lifecycle name.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable
from pathlib import Path

import httpx

from .catalog import _OperationCatalog
from .clients import _AsyncClient, _SyncClient
from .transport import _AsyncTransport, _SyncTransport, _TransportPolicy


def _create_sync_client(
    *,
    repository_root: Path | None = None,
    snapshot_path: Path | None = None,
    credential: str,
    base_url: str,
    timeout: float | httpx.Timeout,
    maximum_retries: int | None = None,
    backoff_seconds: float = 0.0,
    transport: httpx.BaseTransport | None = None,
    sleep: Callable[[float], None] = time.sleep,
) -> _SyncClient:
    if (repository_root is None) == (snapshot_path is None):
        raise ValueError("exactly one of repository_root or snapshot_path is required")
    if repository_root is not None:
        catalog = _OperationCatalog.from_repository(repository_root)
        policy = _TransportPolicy.from_repository(
            repository_root,
            backoff_seconds=backoff_seconds,
            maximum_retries=maximum_retries,
        )
    else:
        assert snapshot_path is not None
        catalog = _OperationCatalog.from_snapshot(snapshot_path)
        policy = _TransportPolicy.from_snapshot(
            snapshot_path,
            backoff_seconds=backoff_seconds,
            maximum_retries=maximum_retries,
        )
    http_client = httpx.Client(
        base_url=base_url,
        headers={"authorization": f"Bearer {credential}"},
        timeout=timeout,
        transport=transport,
        follow_redirects=False,
        trust_env=False,
    )
    return _SyncClient(
        catalog,
        policy,
        _SyncTransport(http_client, policy, sleep),
        close_transport=http_client.close,
        sleep=sleep,
    )


def _create_async_client(
    *,
    repository_root: Path | None = None,
    snapshot_path: Path | None = None,
    credential: str,
    base_url: str,
    timeout: float | httpx.Timeout,
    maximum_retries: int | None = None,
    backoff_seconds: float = 0.0,
    transport: httpx.AsyncBaseTransport | None = None,
    sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
) -> _AsyncClient:
    if (repository_root is None) == (snapshot_path is None):
        raise ValueError("exactly one of repository_root or snapshot_path is required")
    if repository_root is not None:
        catalog = _OperationCatalog.from_repository(repository_root)
        policy = _TransportPolicy.from_repository(
            repository_root,
            backoff_seconds=backoff_seconds,
            maximum_retries=maximum_retries,
        )
    else:
        assert snapshot_path is not None
        catalog = _OperationCatalog.from_snapshot(snapshot_path)
        policy = _TransportPolicy.from_snapshot(
            snapshot_path,
            backoff_seconds=backoff_seconds,
            maximum_retries=maximum_retries,
        )
    http_client = httpx.AsyncClient(
        base_url=base_url,
        headers={"authorization": f"Bearer {credential}"},
        timeout=timeout,
        transport=transport,
        follow_redirects=False,
        trust_env=False,
    )
    return _AsyncClient(
        catalog,
        policy,
        _AsyncTransport(http_client, policy, sleep),
        close_transport=http_client.aclose,
        sleep=sleep,
    )
