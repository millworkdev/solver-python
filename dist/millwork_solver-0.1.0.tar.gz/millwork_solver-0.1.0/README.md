# Millwork Solver for Python

`millwork-solver` is an early preview client for the Millwork Solver API. Import
`millwork_solver` to use the synchronous `Solver` client or the asynchronous
`AsyncSolver` client on CPython 3.11 through 3.14.

Pass `api_key` and `base_url` directly, or use `SOLVERAPI_API_KEY` and
`SOLVERAPI_BASE_URL`. Retry settings use `SOLVERAPI_MAX_RETRIES` (default `2`)
and `SOLVERAPI_RETRY_BACKOFF_MS` (default `500`).

Both clients provide the same typed operation surface, explicit timeout and
close behavior, and receipt-aware responses. Echo reaches a terminal status and
returns a receipt; it does not return result content.
